# GhostsNuker v1.2
A Fast Discord Server Nuker Made By ! 𝙎𝙢𝙤𝙠𝙚𝙧𝙋𝙡𝙖𝙮𝙯_𝙭𝘿xˢᵖʸ#5305 | [Support Server](https://discord.gg/fpwZxqnGDy)
# Preview:
<img align="bottom" alt="preview" width="512px" src="https://media.discordapp.net/attachments/853661592796921906/861463806807244820/unknown.png" />

# Features:  
`1.MASS CHANNEL SPAM`  
`2.MASS ROLE SPAM`  
`3.WIZZ SERVER (MASS CHANNEL + PING SPAM)`  
`4.DELETE ALL CHANNELS`  
`5.DELETE ALL ROLES`  
`6.DELETE ALL EMOJIS`  
`7.BAN ALL MEMBERS`  
`8.KICK ALL MEMBERS`  
`9.UNBAN ALL BANNED MEMBERS`  
`10.DESTROY (THE ULITMATE COMBINATION OF ALL THE ABOVE LISTED COMMANDS)`

# Extra:
**DISABLE EVERYONE**: You Will Find This Option In The Config File. When Set On True It Restricts Everyone Except The Person 
Whose User ID Is Given In The Config File From Running The Commands Of The Nuker

# Requirements:
1.Node.JS  
2.Any Code Editor | Recommended Editor: VSC (Visual Studio Code)  

# Requirements For Phone Users:
1.Termux  
2.Any Phone Code Or Text Editor If You Are Having Problems With Editing Config File  
3.Git And Node.JS Installed In Termux   

# How To Setup:  
# Setup Bot:  
1.Go To [Discord Developer Portal](https://discord.com/developers/applications) And Create New Application.  
2.Add A Bot To Your Application  
3.Go To Bot Section And Scroll Down Until You See **Privileged Gateway Intents**  
4.Check Both `Presence Intent` And `Server Members Intent`    
5.Save Changes  
![example1](https://media.discordapp.net/attachments/861602081596637194/861845896287354920/unknown.png?width=821&height=409)

# Setup Nuker:  
# Without Package Files:  
1.Run Setup.bat  
2.Wait For Npm Init To Run  
3.Enter gts-nuker In Package Name And Hit Enter Key  
4.You Don't Need To Enter Version Just Press Enter Key  
5.Enter discord server nuker In Description And Press Enter Key  
6.Enter nuker.js In Entry Point And Press Enter Key  
7.No Need To Enter Test Command Just Hit Enter Key  
8.In Git Repository Enter This Link: https://github.com/ELITE-SMOKER-69/GtsNuker.git  
9.Again Hit Enter Key In Keywords Cuz Its Not Needed  
10.In Author Enter smoker And Press The Enter Key  
11.Just Hit Enter Key When It Asks License  
12.When It Asks Is This OK? Type Yes And Hit Enter Key  
13.Now System Will Install The Necessary Modules  
14.Now Open Config.Json In Either Notepad or any other text or code editor  
15.In Config.Json You Will Find A Login Field Like This: "login": "Enter Your Bot Token Here"  
16.As Written Enter Your Bot Token In Login Field  
17.You can change prefix field to whatever you want
18.In ID Field Replace My Discord User ID With Your User ID
18.In DisableEveryone Change The Value To False If Value Is false by default then leave it  
19.Now UR Bot Is Ready To Destroy Servers You Just Need To Run Nuker.Bat  

# With Package Files:  
1.Run Install.bat Just To Make Sure You Have All modules install correctly  
2.After Completeing Step 1 Configure Config.Json As Told In The Above Method  
3.Run Nuker.bat And Your Bot Ready To Nuke Servers  

# On Phone:
1.Install Termux  
2.In Termux Run Command `pkg install git`  
3.Then Do `pkg install nodejs`  
4.Change The Directory In Termux To The Location Where You Want To Store The Nuker  
5.Now Do `git clone https://github.com/ELITE-SMOKER-69/GtsNuker.git` In Termux   
6.Then Again Change Directory to The Folder Where The Nuker Is Clone. Example: `cd GtsNuker`  
7.Now Do `npm i discord.js@12.5.3 fs chalk`  
8.Wait For NPM To Install The Modules  
9.After The Modules Are Installed Go To Your App Store And Download Any Text/Code Editor And Open `config.json` In It  
10.Change "Your Bot Token Here" To Your Bot's Token And Make Sure Its Enclosed In Double Quotes  
11.You Can Change Prefix To Whatever You Like  
12.Change Value Of ID To Your Discord User ID  
13.You Can Either Change DisableEveryone To False Or True. It Depends On You  
14.Now Go To Termux And Do `node .`  
15.Now The Nuker Is Ready
16.If You Have Any Problem In Setting Up The Nuker On Phone Then Refer To This [Video](https://www.youtube.com/watch?v=rl5s_N8JkaQ)  

# Notes:
1.Read COPYRIGHT.md Before Trying To Skid/Copy This Nuker  
2.This Tool Was Created For Educational Purposes, I Am Not Responsible For Anything You Do With This Tool  

--END--
