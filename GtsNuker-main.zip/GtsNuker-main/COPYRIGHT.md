Copyright (c) 2021 ELITE SMOKER

You Can Use This Repository For Private And Public Uses But You Can't Modify The Source Code And Distribute It Without The Repository's Owner's Permission As It Is Not An Open Source Project And If You Do Modify And Distribute The Source Code Then You Shall Include The Above Copyright Notice And The Link Of This Repository Without Any Modifications In Your Copy Of This Repository.
