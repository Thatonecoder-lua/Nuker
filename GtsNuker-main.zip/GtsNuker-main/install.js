const title = String.raw`
            ██ ███    ██ ███████ ████████  █████  ██      ██      
            ██ ████   ██ ██         ██    ██   ██ ██      ██      
            ██ ██ ██  ██ ███████    ██    ███████ ██      ██      
            ██ ██  ██ ██      ██    ██    ██   ██ ██      ██      
            ██ ██   ████ ███████    ██    ██   ██ ███████ ███████ 
                                                      
                                                      
`

console.log(title)

console.log(``)
console.log(`                      Tool by: SmokerPlayZ`)
console.log(``)
console.log(``)